Store all photos in Zhaoying's homepage
